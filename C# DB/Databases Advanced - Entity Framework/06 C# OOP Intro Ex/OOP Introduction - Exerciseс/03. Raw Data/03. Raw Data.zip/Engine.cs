﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Engine
{
    public int Speed;
    public int Power;

    public Engine()
    {

    }

    public Engine(int speed, int power)
    {
        this.Speed = speed;
        this.Power = power;
    }
}