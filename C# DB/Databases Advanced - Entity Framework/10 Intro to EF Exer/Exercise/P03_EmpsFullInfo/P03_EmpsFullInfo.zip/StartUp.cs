﻿using System;

using P02_DatabaseFirst;
using P02_DatabaseFirst.Data;
using System.Linq;

namespace P03_EmpsFullInfo
{
    class StartUp
    {
        static void Main(string[] args)
        {

            using (var context = new SoftUniContext())
            {
                var employees = context.Employees
                    .Select(x => (x.FirstName + " " + x.MiddleName + " " + x.LastName + " " + $"{x.Salary:F2}"))
                    .ToList();

                foreach (var emp in employees)
                {
                    Console.WriteLine(emp);
                }
            }
        }
    }
}
