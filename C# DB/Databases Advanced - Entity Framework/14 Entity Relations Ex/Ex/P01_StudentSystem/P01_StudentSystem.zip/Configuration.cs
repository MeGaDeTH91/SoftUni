﻿namespace P01_StudentSystem
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Configuration
    {
        public const string ConnectionString = @"Server = DESKTOP-76VJURB\SQLEXPRESS; Database = Hospital; Integrated Security = true";
    }
}
