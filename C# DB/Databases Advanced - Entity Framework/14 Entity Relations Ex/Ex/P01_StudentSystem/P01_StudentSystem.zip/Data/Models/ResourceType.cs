﻿namespace P01_StudentSystem.Data.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum ResourceType
    {
        Video,
        Presentation,
        Document,
        Other
    }
}
