﻿using System;

namespace P03_GenericScale
{
    class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
