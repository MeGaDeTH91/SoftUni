﻿namespace P07_InfernoInfinity.Models.Enums
{
    public enum GemType
    {
        Chipped = 1,
        Regular = 2,
        Perfect = 5,
        Flawless = 10
    }
}
