﻿[Weapon]
public class Weapon
{
    public Weapon()
    {
    }
}
