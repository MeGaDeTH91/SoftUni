﻿using System;

namespace P05_CreateAttribute
{
    [SoftUni("Gosho")]
    public class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
