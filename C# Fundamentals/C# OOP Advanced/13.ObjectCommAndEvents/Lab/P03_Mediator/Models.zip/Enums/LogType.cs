﻿public enum LogType
{
    ATTACK,
    MAGIC,
    TARGET,
    ERROR,
    EVENT
}