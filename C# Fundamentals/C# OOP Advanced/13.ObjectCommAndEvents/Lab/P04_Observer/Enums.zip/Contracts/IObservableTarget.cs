﻿namespace P04_Observer.Contracts
{
    public interface IObservableTarget : ISubject, ITarget
    {
    }
}
