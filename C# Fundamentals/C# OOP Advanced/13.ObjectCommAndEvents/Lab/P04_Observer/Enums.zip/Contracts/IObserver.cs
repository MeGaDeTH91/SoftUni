﻿namespace P04_Observer.Contracts
{
    public interface IObserver
    {
        void Update(int reward);
    }
}
