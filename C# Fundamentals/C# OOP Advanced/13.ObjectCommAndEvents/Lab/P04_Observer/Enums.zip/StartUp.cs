﻿namespace P04_Observer
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
