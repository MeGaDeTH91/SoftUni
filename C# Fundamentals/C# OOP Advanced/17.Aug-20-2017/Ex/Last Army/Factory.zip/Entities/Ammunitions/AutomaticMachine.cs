﻿public class AutomaticMachine : Ammunition
{
    public const double AutomaticMachineWeight = 6.3d;

    public AutomaticMachine(string name)
        : base(name, AutomaticMachineWeight)
    {

    }
}