﻿public class NightVision : Ammunition
{
    public const double NightVisionWeight = 0.8d;

    public NightVision(string name)
        : base(name, NightVisionWeight)
    {
    }
}