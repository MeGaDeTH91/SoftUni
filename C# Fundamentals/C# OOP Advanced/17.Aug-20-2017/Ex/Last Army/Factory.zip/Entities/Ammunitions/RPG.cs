﻿public class RPG : Ammunition
{
    public const double RPGWeight = 17.1d;

    public RPG(string name)
        : base(name, RPGWeight)
    {
    }
}