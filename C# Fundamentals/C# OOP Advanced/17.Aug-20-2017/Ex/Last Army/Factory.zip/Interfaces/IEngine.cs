﻿public interface IEngine
{
    void Run();
}
