﻿using System;

public interface IReader
{
    string ReadLine();
}
