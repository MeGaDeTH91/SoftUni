﻿public enum HarvesterModeType
{
    Full,
    Half,
    Energy
}
