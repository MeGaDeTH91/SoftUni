﻿using System;
public class Program
{
    static void Main(string[] args)
    {
        Family family = new Family();

        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            string[] currInputTokens = Console.ReadLine().Split();

            string currName = currInputTokens[0];
            int currAge = int.Parse(currInputTokens[1]);

            Person member = new Person()
            {
                Name = currName,
                Age = currAge
            };
            family.AddMember(member);
        }
        var oldestMember = family.GetOldestMember();

        Console.WriteLine(oldestMember);
    }
}


