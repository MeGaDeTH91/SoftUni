﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<Person> people = new List<Person>();

        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            string[] currInputTokens = Console.ReadLine().Split();

            string currName = currInputTokens[0];
            int currAge = int.Parse(currInputTokens[1]);

            Person member = new Person()
            {
                Name = currName,
                Age = currAge
            };
            if (currAge > 30)
            {
                people.Add(member);
            }

        }
        people = people.OrderBy(x => x.Name).ToList();

        Console.WriteLine(string.Join(Environment.NewLine, people));
    }
}


