﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        DateModifier currDateMod = new DateModifier();

        currDateMod.StartDate = Console.ReadLine();
        currDateMod.EndDate = Console.ReadLine();

        long days = currDateMod.days;

        Console.WriteLine(days);
    }
}


