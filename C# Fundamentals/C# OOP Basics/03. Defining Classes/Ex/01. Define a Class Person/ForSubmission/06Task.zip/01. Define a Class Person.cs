﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<Employee> employees = new List<Employee>();

        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            string[] currInput = Console.ReadLine().Split();

            string currName = currInput[0];
            decimal currSalary = decimal.Parse(currInput[1]);
            string currPosition = currInput[2];
            string currDep = currInput[3];

            string currEmail = "n/a";
            int currAge = -1;

            if(currInput.Length == 6)
            {
                currEmail = currInput[4];
                currAge = int.Parse(currInput[5]);
            }
            else if(currInput.Length == 5)
            {
                bool isItAge = int.TryParse(currInput[4], out currAge);
                if (!isItAge)
                {
                    currEmail = currInput[4];
                    currAge = -1;
                }
                
            }

            Employee currEmp = new Employee()
            {
                Name = currName,
                Salary = currSalary,
                Position = currPosition,
                Department = currDep,
                Age = currAge,
                Email = currEmail
            };
            employees.Add(currEmp);
        }
        var highestAverageDep = employees.GroupBy(x => x.Department).OrderByDescending(x => x.Average(y => y.Salary)).First();

        decimal amount = highestAverageDep.Average(x => x.Salary);

        Console.WriteLine($"Highest Average Salary: {highestAverageDep.Key}");
        foreach (var dep in highestAverageDep.OrderByDescending(x => x.Salary))
        {
            Console.WriteLine($"{dep.Name} {dep.Salary:F2} {dep.Email} {dep.Age}");
        }
    }
}


