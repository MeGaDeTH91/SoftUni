﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<Car> cars = new List<Car>();

        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            string[] currTokens = Console.ReadLine().Split();

            string currModel = currTokens[0];
            double currFuelAmount = double.Parse(currTokens[1]);
            double currConsumption = double.Parse(currTokens[2]);

            Car currCar = new Car()
            {
                Model = currModel,
                FuelAmount = currFuelAmount,
                FuelConsumptionPerKm = currConsumption
            };
            cars.Add(currCar);
        }

        string command;
        while ((command = Console.ReadLine()) != "End")
        {
            string[] commTokens = command.Split();
            string driveModel = commTokens[1];
            int kilometres = int.Parse(commTokens[2]);

            Car driveCar = cars.FirstOrDefault(x => x.Model == driveModel);
            driveCar.Drive(kilometres);
        }

        foreach (var car in cars)
        {
            Console.WriteLine($"{car.Model} {car.FuelAmount:F2} {car.DistanceTraveled}");
        }
    }
}


