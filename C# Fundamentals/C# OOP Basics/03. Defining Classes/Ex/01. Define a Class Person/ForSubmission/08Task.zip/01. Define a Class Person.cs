﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<Car> cars = new List<Car>();

        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            string[] currTokens = Console.ReadLine().Split();

            string currModel = currTokens[0];
            int engineSpeed = int.Parse(currTokens[1]);
            int enginePower = int.Parse(currTokens[2]);
            Engine currEngine = new Engine()
            {
                EngineSpeed = engineSpeed,
                EnginePower = enginePower
            };
            int cargoWeight = int.Parse(currTokens[3]);
            string cargoType = currTokens[4];
            Cargo newCargo = new Cargo()
            {
                CargoWeight = cargoWeight,
                CargoType = cargoType
            };
            Tire[] tires = new Tire[4];
            int tireIndex = 5;
            for (int index = 0; index < 4; index++)
            {
                Tire newTire = new Tire()
                {
                    Pressure = double.Parse(currTokens[tireIndex]),
                    Age = int.Parse(currTokens[tireIndex + 1])
                };
                tireIndex += 2;
                tires[index] = newTire;
            }

            Car currCar = new Car(currModel, currEngine, newCargo, tires);
            cars.Add(currCar);
        }

        string seekType = Console.ReadLine();
        var printList = new List<Car>();

        if(seekType == "fragile")
        {
            printList = cars.Where(x => x.Cargo.CargoType == seekType && x.Tires.Any(y => y.Pressure < 1)).ToList();
        }
        else if(seekType == "flamable")
        {
            printList = cars.Where(x => x.Cargo.CargoType == seekType && x.Engine.EnginePower > 250).ToList();
        }

        foreach (var car in printList)
        {
            Console.WriteLine(car.Model);
        }
    }
}


