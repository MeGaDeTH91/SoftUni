﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<Rectangle> rectangles = new List<Rectangle>();

        double[] initialInputs = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(double.Parse).ToArray();

        double rectangleNum = initialInputs[0];
        double numberOfChecks = initialInputs[1];

        for (int i = 0; i < rectangleNum; i++)
        {
            string[] currRectangleDetails = Console.ReadLine().Split(new[] { ' '},StringSplitOptions.RemoveEmptyEntries).ToArray();
            string currId = currRectangleDetails[0];
            double currWidth = double.Parse(currRectangleDetails[1]);
            double currHeight = double.Parse(currRectangleDetails[2]);
            double topLeftX = double.Parse(currRectangleDetails[3]);
            double topLeftY = double.Parse(currRectangleDetails[4]);

            Rectangle currRectangle = new Rectangle(currId, currWidth, currHeight, topLeftX, topLeftY);
            rectangles.Add(currRectangle);
        }

        for (int i = 0; i < numberOfChecks; i++)
        {
            string[] currCheckDetails = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToArray();
            string firstId = currCheckDetails[0];
            string secondId = currCheckDetails[1];

            var firstRectangle = rectangles.FirstOrDefault(x => x.Id == firstId);
            var secondRectangle = rectangles.FirstOrDefault(x => x.Id == secondId);

            bool isItSuccess = firstRectangle.TheyIntersect(secondRectangle);
            if (isItSuccess)
            {
                Console.WriteLine("true");
            }
            else
            {
                Console.WriteLine("false");
            }
        }
    }
}


