﻿using System;
using System.Collections.Generic;
using System.Text;

public class Tire
{
    public double Pressure { get; set; }
    public int Age { get; set; }
}

