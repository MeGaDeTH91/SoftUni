﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

public class Program
{
    static void Main(string[] args)
    {
        List<Engine> engines = new List<Engine>();
        List<Car> cars = new List<Car>();

        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            string[] engineTokens = Console.ReadLine().Split(new[] { ' '},StringSplitOptions.RemoveEmptyEntries);

            string currEngineModel = engineTokens[0];
            string currPower = engineTokens[1];

            Engine eng = new Engine()
            {
                Model = currEngineModel,
                Power = currPower
            };

            if(engineTokens.Length == 4)
            {
                string currDisp = engineTokens[2];
                string currEff = engineTokens[3];

                eng.Displacement = currDisp;
                eng.Efficiency = currEff;
            }
            else if(engineTokens.Length == 3)
            {
                BigInteger displ;
                bool isItDispl = BigInteger.TryParse(engineTokens[2], out displ);

                if (isItDispl)
                {
                    eng.Displacement = engineTokens[2];
                }
                else
                {
                    eng.Efficiency = engineTokens[2];
                }
            }
            engines.Add(eng);
        }

        int m = int.Parse(Console.ReadLine());

        for (int i = 0; i < m; i++)
        {
            string[] currCarTokens = Console.ReadLine().Split(new[] { ' '},StringSplitOptions.RemoveEmptyEntries);

            string currCarModel = currCarTokens[0];
            string currEngineModel = currCarTokens[1];

            var engine = engines.FirstOrDefault(x => x.Model == currEngineModel);

            Car currCar = new Car()
            {
                Model = currCarModel,
                Engine = engine
            };

            if(currCarTokens.Length == 4)
            {
                string currWeight = currCarTokens[2];
                string currColor = currCarTokens[3];

                currCar.Weight = currWeight;
                currCar.Color = currColor;
            }
            else if(currCarTokens.Length == 3)
            {
                BigInteger weight;
                bool isItDispl = BigInteger.TryParse(currCarTokens[2], out weight);

                if (isItDispl)
                {
                    currCar.Weight = currCarTokens[2];
                }
                else
                {
                    string currColor = currCarTokens[2];
                    currCar.Color = currColor;
                }
            }
            cars.Add(currCar);
        }
        foreach (var car in cars)
        {
            Console.WriteLine(car);
        }
    }
}


