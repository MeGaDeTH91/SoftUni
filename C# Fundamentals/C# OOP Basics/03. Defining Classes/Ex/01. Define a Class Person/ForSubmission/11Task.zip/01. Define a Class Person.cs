﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<Trainer> trainers = new List<Trainer>();

        string command;
        while ((command = Console.ReadLine()) != "Tournament")
        {
            string[] commTokens = command.Split(new[] { ' '},StringSplitOptions.RemoveEmptyEntries);

            string trainerName = commTokens[0];

            string pokemonName = commTokens[1];
            string pokemonElement = commTokens[2];
            int pokemonHealth = int.Parse(commTokens[3]);

            var trainer = trainers.FirstOrDefault(x => x.Name == trainerName);
            if(trainer == null)
            {
                Trainer newTrain = new Trainer()
                {
                    Name = trainerName,
                };
                trainers.Add(newTrain);
            }
            trainer = trainers.FirstOrDefault(x => x.Name == trainerName);
            Pokemon newPoke = new Pokemon()
            {
                Name = pokemonName,
                Element = pokemonElement,
                Health = pokemonHealth
            };
            trainer.Pokemons.Add(newPoke);
        }

        string seekElement;
        while ((seekElement = Console.ReadLine()) != "End")
        {
            foreach (var trainer in trainers)
            {
                if(trainer.Pokemons.Any(x => x.Element == seekElement))
                {
                    trainer.BadgeNumber++;
                }
                else
                {
                    foreach (var poke in trainer.Pokemons)
                    {
                        poke.Health -= 10;
                    }
                    trainer.Pokemons.RemoveAll(x => x.Health <= 0);
                }
            }
        }
        foreach (var trainer in trainers.OrderByDescending(x => x.BadgeNumber))
        {
            Console.WriteLine($"{trainer.Name} {trainer.BadgeNumber} {trainer.Pokemons.Count}");
        }
    }
}


