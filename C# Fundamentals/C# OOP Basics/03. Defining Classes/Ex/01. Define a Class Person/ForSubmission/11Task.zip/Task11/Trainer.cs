﻿using System;
using System.Collections.Generic;
using System.Text;

public class Trainer
{
    public string Name { get; set; }
    public int BadgeNumber { get; set; }
    public List<Pokemon> Pokemons { get; set; }
    
    public Trainer(string name, int badgeNumber)
    {
        this.Name = name;
        this.BadgeNumber = badgeNumber;
        this.Pokemons = new List<Pokemon>();
    }
    public Trainer()
    {
        this.Pokemons = new List<Pokemon>();
    }
}

