﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<Person> people = new List<Person>();

        string command;
        while ((command = Console.ReadLine()) != "End")
        {
            string[] currTokens = command.Split(new[] { ' '},StringSplitOptions.RemoveEmptyEntries);

            string currName = currTokens[0];
            string property = currTokens[1];
            if(!people.Any(x => x.Name == currName))
            {
                Person addPerson = new Person()
                {
                    Name = currName
                };
                people.Add(addPerson);
            }

            var currPerson = people.FirstOrDefault(x => x.Name == currName);

            switch (property)
            {
                case "company":
                    string company = currTokens[2];
                    string department = currTokens[3];
                    string salary = $"{decimal.Parse(currTokens[4]):F2}";
                    currPerson.Company = $"{company} {department} {salary}";
                    break;
                case "pokemon":
                    string pokemonName = currTokens[2];
                    string pokemonType = currTokens[3];                    
                    currPerson.Pokemons.Add($"{pokemonName} {pokemonType}");
                    break;
                case "parents":
                    string parentName = currTokens[2];
                    string parentBirthday = currTokens[3];
                    currPerson.Parents.Add($"{parentName} {parentBirthday}");
                    break;
                case "children":
                    string childName = currTokens[2];
                    string childBirthday = currTokens[3];
                    currPerson.Children.Add($"{childName} {childBirthday}");
                    break;
                case "car":
                    string carModel = currTokens[2];
                    string carSpeed = currTokens[3];
                    currPerson.Car = $"{carModel} {carSpeed}";
                    break;
                default:
                    break;
            }
        }
        string seekName = Console.ReadLine();

        var printPerson = people.FirstOrDefault(x => x.Name == seekName);

        Console.WriteLine(seekName);
        Console.WriteLine("Company:");
        if(printPerson.Company != null)
        {
            Console.WriteLine(printPerson.Company);
        }

        Console.WriteLine("Car:");
        if (printPerson.Car != null)
        {
            Console.WriteLine(printPerson.Car);
        }
        Console.WriteLine("Pokemon:");
        foreach (var poke in printPerson.Pokemons)
        {
            Console.WriteLine(poke);
        }

        Console.WriteLine($"Parents:");
        foreach (var parent in printPerson.Parents)
        {
            Console.WriteLine(parent);
        }
        Console.WriteLine($"Children:");
        foreach (var child in printPerson.Children)
        {
            Console.WriteLine(child);
        }
    }
}


