﻿using System;
using System.Collections.Generic;
using System.Text;

public class Person
{
    public string Name { get; set; }
    public string Company { get; set; }
    public string Car { get; set; }
    public List<string> Pokemons { get; set; }
    public List<string> Parents { get; set; }
    public List<string> Children { get; set; }

    public Person()
    {
        this.Pokemons  = new List<string>();
        this.Parents = new List<string>();
        this.Children = new List<string>();
    }
}

