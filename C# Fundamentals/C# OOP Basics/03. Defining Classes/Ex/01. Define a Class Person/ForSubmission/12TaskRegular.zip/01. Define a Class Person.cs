﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        List<Person> people = new List<Person>();

        string command;
        while ((command = Console.ReadLine()) != "End")
        {
            string[] currTokens = command.Split(new[] { ' '},StringSplitOptions.RemoveEmptyEntries);

            string currName = currTokens[0];
            string property = currTokens[1];
            if(!people.Any(x => x.Name == currName))
            {
                Person addPerson = new Person()
                {
                    Name = currName
                };
                people.Add(addPerson);
            }

            var currPerson = people.FirstOrDefault(x => x.Name == currName);

            switch (property)
            {
                case "company":
                    string company = currTokens[2];
                    string department = currTokens[3];
                    decimal salary = decimal.Parse(currTokens[4]);
                    Company newComp = new Company()
                    {
                        Name = company,
                        Department = department,
                        Salary = salary
                    };
                    currPerson.Company = newComp;
                    break;
                case "pokemon":
                    string pokemonName = currTokens[2];
                    string pokemonType = currTokens[3];
                    Pokemon newPoke = new Pokemon()
                    {
                        Name = pokemonName,
                        Type = pokemonType
                    };
                    currPerson.Pokemons.Add(newPoke);
                    break;
                case "parents":
                    string parentName = currTokens[2];
                    string parentBirthday = currTokens[3];
                    Parent newParent = new Parent()
                    {
                        Name = parentName,
                        BirthDay = parentBirthday
                    };
                    currPerson.Parents.Add(newParent);
                    break;
                case "children":
                    string childName = currTokens[2];
                    string childBirthday = currTokens[3];
                    Child newChild = new Child()
                    {
                        Name = childName,
                        BirthDay = childBirthday
                    };
                    currPerson.Children.Add(newChild);
                    break;
                case "car":
                    string carModel = currTokens[2];
                    int carSpeed = int.Parse(currTokens[3]);
                    Car newCar = new Car()
                    {
                        Model = carModel,
                        Speed = carSpeed
                    };
                    currPerson.Car = newCar;
                    break;
                default:
                    break;
            }
        }
        string seekName = Console.ReadLine();

        var printPerson = people.FirstOrDefault(x => x.Name == seekName);

        Console.WriteLine(seekName);
        Console.WriteLine(printPerson.ToString());
        
    }
}


