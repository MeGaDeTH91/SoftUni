﻿using System;
using System.Collections.Generic;
using System.Text;

public class Parent
{
    public string Name { get; set; }

    public string BirthDay { get; set; }

    public Parent()
    {

    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"{this.Name} {this.BirthDay}");
        return sb.ToString().TrimEnd();
    }
}
