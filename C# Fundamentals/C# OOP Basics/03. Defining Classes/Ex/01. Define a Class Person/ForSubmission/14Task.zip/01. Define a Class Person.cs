﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Program
{
    static void Main(string[] args)
    {
        Hierarchy currCatList = new Hierarchy();

        string input;
        while ((input = Console.ReadLine()) != "End")
        {
            string[] currTokens = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            string catType = currTokens[0];
            string catName = currTokens[1];

            switch (catType.ToLower())
            {
                case"siamese":
                    long earSize = long.Parse(currTokens[2]);
                    Siamese addSiam = new Siamese()
                    {
                        Name = catName,
                        EarSize = earSize
                    };
                    currCatList.SiameseCats.Add(addSiam);
                    break;
                case "cymric":
                    double furLength = double.Parse(currTokens[2]);
                    Cymric addCymr = new Cymric()
                    {
                        Name = catName,
                        FurLength  = furLength
                    };
                    currCatList.CymricCats.Add(addCymr);
                    break;
                case "streetextraordinaire":
                    long decibels = long.Parse(currTokens[2]);
                    StreetExtraordinaire addStreet = new StreetExtraordinaire()
                    {
                        Name = catName,
                        MeowDecibels = decibels
                    };
                    currCatList.StreetExtraordinaireCats.Add(addStreet);
                    break;
                default:
                    break;
            }
        }

        string seekCat = Console.ReadLine();

        var cat = currCatList.GetMeTheDamnCat(seekCat);

        Console.WriteLine(cat);
    }
}


