﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cymric
{
    public string Name { get; set; }
    public double FurLength { get; set; }
}
