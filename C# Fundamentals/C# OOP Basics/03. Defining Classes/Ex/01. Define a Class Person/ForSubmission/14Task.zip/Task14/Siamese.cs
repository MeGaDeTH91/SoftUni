﻿using System;
using System.Collections.Generic;
using System.Text;

public class Siamese
{
    public string Name { get; set; }
    public long EarSize { get; set; }
}
