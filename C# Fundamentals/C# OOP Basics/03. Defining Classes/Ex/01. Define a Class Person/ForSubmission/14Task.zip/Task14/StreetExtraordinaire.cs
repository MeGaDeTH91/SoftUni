﻿using System;
using System.Collections.Generic;
using System.Text;

public class StreetExtraordinaire
{
    public string Name { get; set; }
    public long MeowDecibels { get; set; }
}
