﻿public enum DiscountType
{
    None,
    SecondVisit,
    VIP
}