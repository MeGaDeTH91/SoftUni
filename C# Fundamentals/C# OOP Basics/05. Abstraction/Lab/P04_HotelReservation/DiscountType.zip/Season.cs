﻿public enum Season
{
    Autumn,
    Spring,
    Winter,
    Summer
}

