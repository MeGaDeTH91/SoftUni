﻿using System;

namespace P04_Team
{
    public class P04_Team
    {
        static void Main(string[] args)
        {
            
        }
    }
}
