﻿using System;

namespace P01_SingleInh
{
    class P01_SingleInh
    {
        static void Main(string[] args)
        {
            Dog dog = new Dog();
            dog.Eat();
            dog.Bark();
        }
    }
}
