﻿using System;

namespace P02_MultipleInh
{
    class P02_MultipleInh
    {
        static void Main(string[] args)
        {
            Puppy pupp = new Puppy();

            pupp.Eat();
            pupp.Bark();
            pupp.Weep();
        }
    }
}
