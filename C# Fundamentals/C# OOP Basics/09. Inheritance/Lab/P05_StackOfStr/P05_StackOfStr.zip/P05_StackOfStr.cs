﻿using System;

namespace P05_StackOfStr
{
    class P05_StackOfStr
    {
        static void Main(string[] args)
        {
            
        }
    }
}
