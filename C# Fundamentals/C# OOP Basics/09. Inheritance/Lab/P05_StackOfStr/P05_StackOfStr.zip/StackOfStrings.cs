﻿using System;
using System.Collections.Generic;
using System.Linq;

public class StackOfStrings
{
    private List<string> data;

    public StackOfStrings()
    {
        this.data = new List<string>();
    }

    public void Push(string item)
    {
        this.data.Add(item);
    }

    public string Pop()
    {
        string element = this.data.Last();
        this.data.RemoveAt(this.data.Count - 1);
        return element;
    }

    public string Peek()
    {
        string element = this.data.Last();
        return element;
    }

    public bool IsEmpty()
    {
        return this.data.Count == 0;
    }
}
