﻿public interface ICall
{
    string[] Numbers { get; }
    string Call(string number);
}
