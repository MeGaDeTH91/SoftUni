﻿using System;

public class Robot : WhiteWalker, IRobot
{
    public Robot(string model, string id) : base(model, id)
    {
    }
}
