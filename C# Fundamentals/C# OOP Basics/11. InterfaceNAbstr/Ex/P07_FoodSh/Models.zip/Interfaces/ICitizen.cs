﻿using System;

public interface ICitizen
{
    string Name { get; }
    int Age { get; }
    string Id { get; }
    DateTime Birthdate { get; }
}
