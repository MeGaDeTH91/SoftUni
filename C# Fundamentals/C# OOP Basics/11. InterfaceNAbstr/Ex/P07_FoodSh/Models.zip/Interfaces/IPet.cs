﻿using System;

public interface IPet
{
    string Name { get; }
    DateTime Birthdate { get; }
}
