﻿public enum CorpsType
{
    Airforces,
    Marines
}
