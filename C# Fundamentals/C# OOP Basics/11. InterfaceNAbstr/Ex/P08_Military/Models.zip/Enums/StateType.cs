﻿public enum StateType
{
    inProgress,
    Finished
}
