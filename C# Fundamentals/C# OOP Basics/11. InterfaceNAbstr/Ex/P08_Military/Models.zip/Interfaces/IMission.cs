﻿public interface IMission
{
    string CodeName { get; }
    StateType State { get; }
}