﻿public interface IRepair
{
    int HoursWorked { get; }
    string PartName { get; }
}