﻿public interface ISpecialisedSoldier
{
    CorpsType Corps { get; set; }
}