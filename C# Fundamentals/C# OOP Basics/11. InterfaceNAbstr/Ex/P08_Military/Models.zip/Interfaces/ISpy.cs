﻿using System;

public interface ISpy
{
    int CodeNumber { get; }
}
