﻿public interface IAddRemoveCollection<T>
{
    int Add(T element);
    T Remove();
}