﻿public interface IMyList<T>
{
    int Add(T element);
    T Remove();
}