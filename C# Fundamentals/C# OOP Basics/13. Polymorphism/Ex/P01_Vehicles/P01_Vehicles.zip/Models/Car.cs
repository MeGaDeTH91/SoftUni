﻿using System;

public class Car : Vehicle
{
    public Car(double fuelQuant, double fuelConsum) : base(fuelQuant, fuelConsum)
    {
        this.FuelConsumptionIncrease();
    }

    public override string Drive(double kilometres)
    {
        double neededFuel = kilometres * this.FuelConsumptionPerKm;
        if(this.FuelQuantity >= neededFuel)
        {
            this.FuelQuantity -= neededFuel;
            return $"Car travelled {kilometres} km";
        }
        else
        {
            return "Car needs refueling";
        }
    }

    public override void FuelConsumptionIncrease()
    {
        this.FuelConsumptionPerKm += 0.9;
    }

    public override void Refuel(double liters)
    {
        this.FuelQuantity += liters;
    }
}
