﻿using System;

public class Truck : Vehicle
{
    public Truck(double fuelQuant, double fuelConsum) : base(fuelQuant, fuelConsum)
    {
        this.FuelConsumptionIncrease();
    }

    public override string Drive(double kilometres)
    {
        double neededFuel = kilometres * this.FuelConsumptionPerKm;
        if (this.FuelQuantity >= neededFuel)
        {
            this.FuelQuantity -= neededFuel;
            return $"Truck travelled {kilometres} km";
        }
        else
        {
            return "Truck needs refueling";
        }
    }

    public override void FuelConsumptionIncrease()
    {
        this.FuelConsumptionPerKm += 1.6;
    }

    public override void Refuel(double liters)
    {
        this.FuelQuantity += 0.95 * liters;
    }
}
