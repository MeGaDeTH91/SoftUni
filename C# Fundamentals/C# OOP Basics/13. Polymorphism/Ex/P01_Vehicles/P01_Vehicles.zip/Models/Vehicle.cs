﻿using System;

public abstract class Vehicle
{
    public double FuelQuantity { get; set; }
    public double FuelConsumptionPerKm { get; set; }
    public abstract void FuelConsumptionIncrease();
    public abstract void Refuel(double liters);
    public abstract string Drive(double kilometres);
    public override string ToString()
    {
        return $"{this.GetType()}: {this.FuelQuantity:F2}";
    }

    public Vehicle(double fuelQuant, double fuelConsum)
    {
        this.FuelQuantity = fuelQuant;
        this.FuelConsumptionPerKm = fuelConsum;
    }
}
