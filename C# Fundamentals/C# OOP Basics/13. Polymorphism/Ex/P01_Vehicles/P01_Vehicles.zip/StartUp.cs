﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;

namespace P01_Vehicles
{
    class StartUp
    {
        static void Main(string[] args)
        {
            string[] carInput = Console.ReadLine().Split();
            double carFuelQuantity = double.Parse(carInput[1]);
            double carFuelConsumption = double.Parse(carInput[2]);
            Vehicle car = new Car(carFuelQuantity, carFuelConsumption);

            string[] truckInput = Console.ReadLine().Split();
            double truckFuelQuantity = double.Parse(truckInput[1]);
            double truckFuelConsumption = double.Parse(truckInput[2]);
            Vehicle truck = new Truck(truckFuelQuantity, truckFuelConsumption);

            Vehicle[] vehicleArr = new Vehicle[2] {car, truck };

            StringBuilder sb = new StringBuilder();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] commTokens = Console.ReadLine().Split();

                string commType = commTokens[0];
                string vehicleType = commTokens[1];

                switch (commType)
                {
                    case "Drive":
                        double kilometres = double.Parse(commTokens[2]);
                        sb.AppendLine(((Vehicle)vehicleArr.FirstOrDefault(x => x.GetType().ToString() == vehicleType)).Drive(kilometres));
                        break;
                    case "Refuel":
                        double fuelToAdd = double.Parse(commTokens[2]);
                        ((Vehicle)vehicleArr.FirstOrDefault(x => x.GetType().ToString() == vehicleType)).Refuel(fuelToAdd);
                        break;
                    default:
                        break;
                }
            }
            sb.AppendLine(car.ToString());
            sb.AppendLine(truck.ToString());
            Console.WriteLine(sb.ToString().TrimEnd());
        }
    }
}
