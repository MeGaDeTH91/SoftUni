﻿using System;

namespace P02_Animals
{
    class P02_Animals
    {
        static void Main(string[] args)
        {
            
        }
    }
}
