﻿using System;

namespace P03_Shapes
{
    class P03_Shapes
    {
        static void Main(string[] args)
        {
            
        }
    }
}
