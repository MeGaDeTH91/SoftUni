﻿namespace Forum.App.UserInterface.Contracts
{
    public interface IInput
    {
        bool AddCharacter(char character);

        void Delete();
    }
}