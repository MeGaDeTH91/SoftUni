﻿using System;

public class AirMonument : Monument
{
    public AirMonument(string name, int affinity) : base(name, affinity)
    {
    }
}
