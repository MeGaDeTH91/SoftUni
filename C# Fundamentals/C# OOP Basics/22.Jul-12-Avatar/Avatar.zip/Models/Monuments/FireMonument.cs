﻿using System;

public class FireMonument : Monument
{
    public FireMonument(string name, int affinity) : base(name, affinity)
    {
    }
}
