﻿using System;

public class WaterMonument : Monument
{
    public WaterMonument(string name, int affinity) : base(name, affinity)
    {
    }
}
