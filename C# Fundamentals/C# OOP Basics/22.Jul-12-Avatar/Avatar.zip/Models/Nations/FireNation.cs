﻿using System.Collections.Generic;

public class FireNation : Nation
{
    List<Bender> FireBenders;
    List<Monument> FireMonuments;

    public FireNation()
    {
        this.FireBenders = new List<Bender>();
        this.FireMonuments = new List<Monument>();
    }
}
