﻿public interface IHealable
{
    void Heal(Character character);
}
