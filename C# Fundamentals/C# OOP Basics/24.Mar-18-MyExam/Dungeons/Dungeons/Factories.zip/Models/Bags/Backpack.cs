﻿using System;

public class Backpack : Bag
{
    private const int Initial_Backpack_Capacity = 100;

    public Backpack() : base(Initial_Backpack_Capacity)
    {
    }


}
