﻿using System;

public class Satchel : Bag
{
    private const int Initial_Satchel_Capacity = 20;

    public Satchel() : base(Initial_Satchel_Capacity)
    {
    }


}
