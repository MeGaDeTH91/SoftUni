﻿namespace MyCoolWebServer.Server.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
