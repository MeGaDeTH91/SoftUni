﻿namespace MyCoolWebServer.Server.Contracts
{
    public interface IView
    {
        string View();
    }
}
