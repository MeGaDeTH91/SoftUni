# My Cool Web Server

Simple web server built from scratch as an exercise for [https://softuni.bg/trainings/1736/c-sharp-web-development-basics-september-2017](https://softuni.bg/trainings/1736/c-sharp-web-development-basics-september-2017). Enjoy! :)