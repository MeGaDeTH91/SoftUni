﻿class Launcher
{
    static void Main(string[] args)
    {
    }
}
