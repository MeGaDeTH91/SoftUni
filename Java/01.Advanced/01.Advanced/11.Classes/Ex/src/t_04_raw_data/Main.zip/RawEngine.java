package t_04_raw_data;

public class RawEngine {
    private int speed;
    private int power;

    public RawEngine(int speed, int power) {
        this.speed = speed;
        this.power = power;
    }

    public int getPower() {
        return power;
    }
}
