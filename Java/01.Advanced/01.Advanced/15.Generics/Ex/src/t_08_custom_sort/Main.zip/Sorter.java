package t_08_custom_sort;

public class Sorter {
    public static void sort(MyList list) {
        list.sort();
    }
}
