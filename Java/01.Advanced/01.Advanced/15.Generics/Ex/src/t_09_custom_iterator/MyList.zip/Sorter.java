package t_09_custom_iterator;

public class Sorter {
    public static void sort(MyList list) {
        list.sort();
    }
}
