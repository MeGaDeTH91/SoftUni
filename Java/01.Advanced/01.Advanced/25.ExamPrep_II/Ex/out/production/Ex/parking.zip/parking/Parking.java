package parking;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Parking {
    private List<Car> data;
    private String type;
    private int capacity;

    public Parking(String type, int capacity) {
        data = new ArrayList<>();
        this.type = type;
        this.capacity = capacity;
    }

    public void add(Car car) {
        if (data.size() + 1 < capacity) {
            data.add(car);
        }
    }

    public boolean remove(String manufacturer, String model) {
        return data.removeIf(x -> x.getManufacturer().equals(manufacturer) && x.getModel().equals(model));
    }

    public Car getLatestCar() {
        if (data.isEmpty()) {
            return null;
        }

        return Collections.max(data, Comparator.comparing(Car::getYear));
    }

    public Car getCar(String manufacturer, String model) {
        return data.stream()
                .filter(x -> x.getManufacturer().equals(manufacturer) && x.getModel().equals(model))
                .findFirst()
                .orElse(null);
    }

    public int getCount() {
        return data.size();
    }

    public String getStatistics() {
        StringBuilder sb = new StringBuilder(53);

        sb.append("The cars are parked in ").append(type).append(':').append('\n');

        for (Car car: data) {
            sb.append(car.toString()).append('\n');
        }

        return sb.toString().trim();
    }
}
