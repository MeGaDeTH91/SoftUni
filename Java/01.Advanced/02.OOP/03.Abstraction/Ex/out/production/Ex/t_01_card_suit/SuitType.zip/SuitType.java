package t_01_card_suit;

public enum SuitType {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
