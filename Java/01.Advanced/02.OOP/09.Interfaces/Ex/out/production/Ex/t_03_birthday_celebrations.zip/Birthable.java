public interface Birthable {
    String getName();
    String getBirthDate();
}
