public interface Modelable {
    String getModel();
}
