public interface Person {
    int getAge();
}
