public interface Groupable {
    String getGroup();
}
