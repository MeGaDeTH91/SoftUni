package contracts;

public interface Commando extends SpecialisedSoldier {
}
