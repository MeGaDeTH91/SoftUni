package contracts;

public interface Engineer extends SpecialisedSoldier {
}
