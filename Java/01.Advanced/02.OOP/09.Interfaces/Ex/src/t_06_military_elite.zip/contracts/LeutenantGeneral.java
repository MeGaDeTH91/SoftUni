package contracts;

public interface LeutenantGeneral extends Private {
}
