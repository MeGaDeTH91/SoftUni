package contracts;

public interface Mission {
    void completeMission();
}
