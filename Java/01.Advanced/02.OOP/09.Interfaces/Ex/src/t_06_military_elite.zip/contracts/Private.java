package contracts;

public interface Private extends Soldier {
}
