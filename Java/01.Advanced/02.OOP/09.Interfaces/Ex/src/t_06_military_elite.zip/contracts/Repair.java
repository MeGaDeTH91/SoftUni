package contracts;

public interface Repair {
}
