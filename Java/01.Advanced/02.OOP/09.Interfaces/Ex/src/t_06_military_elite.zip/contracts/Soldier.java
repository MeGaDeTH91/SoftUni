package contracts;

public interface Soldier {

    String getId();
}
