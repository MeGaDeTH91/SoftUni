package contracts;

public interface SpecialisedSoldier extends Private {
    String getCorps();
}
