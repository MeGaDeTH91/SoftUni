package contracts;

public interface Spy extends Soldier {
}
