public interface AddRemovable {
    String remove();
}
