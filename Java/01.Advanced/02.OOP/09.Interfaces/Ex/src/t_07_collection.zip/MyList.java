public interface MyList {
    int getUsed();
}
