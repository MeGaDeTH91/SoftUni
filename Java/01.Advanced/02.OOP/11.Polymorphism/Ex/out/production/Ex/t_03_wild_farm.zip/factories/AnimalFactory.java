package factories;


import animals.Animal;
import animals.Mouse;
import animals.Zebra;
import animals.Cat;
import animals.Tiger;

public class AnimalFactory {
    public static Animal createAnimal(String[] tokens) {
        String animalType = tokens[0];
        String animalName = tokens[1];
        double animalWeight = Double.parseDouble(tokens[2]);
        String animalRegion = tokens[3];

        Animal createdAnimal;

        switch (animalType) {
            case "Mouse":
                createdAnimal = new Mouse(animalName, animalType, animalWeight, animalRegion);
                break;
            case "Zebra":
                createdAnimal = new Zebra(animalName, animalType, animalWeight, animalRegion);
                break;
            case "Cat":
                createdAnimal = new Cat(animalName, animalType, animalWeight, animalRegion, tokens[4]);
                break;
            case "Tiger":
                createdAnimal = new Tiger(animalName, animalType, animalWeight, animalRegion);
                break;
            default:
                throw new IllegalArgumentException("Invalid animal type.");
        }

        return createdAnimal;
    }
}
