package factories;

import foods.Food;
import foods.Meat;
import foods.Vegetable;

public class FoodFactory {
    public static Food createFood(String[] tokens) {
        String foodType = tokens[0];
        int foodQuantity = Integer.parseInt(tokens[1]);

        Food createdFood;

        switch (foodType) {
            case "Vegetable":
                createdFood = new Vegetable(foodQuantity);
                break;
            case "Meat":
                createdFood = new Meat(foodQuantity);
                break;
            default:
                throw new IllegalArgumentException("Invalid food type.");
        }

        return createdFood;
    }
}
