package CounterStriker.core;

public interface Engine extends Runnable {
}
