﻿namespace CTF.Framework.TestRunner
{
    using System;
    using System.Text;

    public class Runner
    {
        private readonly StringBuilder stringBuilder;

        public Runner()
        {
            this.stringBuilder = new StringBuilder();
        }

        public string Run(string assemblyPath)
        {
            throw new NotImplementedException();
        }
    }
}
