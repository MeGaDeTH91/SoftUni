﻿namespace DeprecatedClass
{
    using System.Reflection;

    public class PrivateObject
    {
    }
}
