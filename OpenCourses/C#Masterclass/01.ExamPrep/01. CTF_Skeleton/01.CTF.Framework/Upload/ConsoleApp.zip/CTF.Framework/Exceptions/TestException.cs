﻿namespace CTF.Framework.Exceptions
{
    using System;

    public class TestException : Exception
    {
    }
}
