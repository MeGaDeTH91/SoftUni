﻿namespace MyCustomHttpServer
{
    public static class StartUp
    {
        public static void Main(string[] args)
        {
        }
    }
}