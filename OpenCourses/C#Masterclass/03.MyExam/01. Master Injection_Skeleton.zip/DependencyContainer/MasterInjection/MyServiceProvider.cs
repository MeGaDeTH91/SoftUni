﻿namespace MasterInjection
{
    using System;

    public class MyServiceProvider : IMyServiceProvider
    {
        public MyServiceProvider()
        {
        }

        public void Add<TSource, TDestination>()
            where TDestination : TSource
        {
            throw new NotImplementedException();
        }

        public object CreateInstance(Type type)
        {
            throw new NotImplementedException();
        }

        public T CreateInstance<T>()
        {
            throw new NotImplementedException();
        }
    }
}
