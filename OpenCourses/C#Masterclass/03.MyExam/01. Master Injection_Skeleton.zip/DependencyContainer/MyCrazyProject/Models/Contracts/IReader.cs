﻿namespace MyCrazyProject.Models.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
