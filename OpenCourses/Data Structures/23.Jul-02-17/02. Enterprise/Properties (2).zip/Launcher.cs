﻿using System;

class Launcher
{
    static void Main(string[] args)
    {
        //IEnterprise currEnt = new Enterprise();
        //Employee employee = new Employee("dude", "dudeLast", 1000, Position.Owner, DateTime.Now);
        //currEnt.Add(employee);

        //bool isWorking = currEnt.Contains(employee.Id);
        //bool isWorking2 = currEnt.Contains(employee);
    }
}
